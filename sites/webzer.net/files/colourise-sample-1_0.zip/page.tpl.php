<?php
// $id: page.tpl.php, 2008/11/04 gibbo Exp $
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php print $language->language ?>" lang="<?php print $language->language ?>" dir="<?php print $language->dir ?>">

<head>
<?php print $head ?>
<title><?php print $head_title; ?></title>	
<?php print $styles; ?>		
<?php print $scripts; ?>
</head>

<body>

<!-- wrap starts here -->
<div id="wrap">

	<!--header -->
	<div id="header">			
				
		<h1 id="logo-text"><a href="index.html" title="">Colourise</a></h1>		
		<p id="intro">
		Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec libero. Suspendisse bibendum. 
		Cras id urna. Morbi tincidunt, orci ac convallis aliquam. 
		</p>	
		
		<div  id="nav">
			<ul>
				<li id="current"><a href="index.html">Home</a></li>
				<li><a href="style.html">Style Demo</a></li>
				<li><a href="index.html">Downloads</a></li>
				<li><a href="index.html">Services</a></li>
				<li><a href="index.html">Support</a></li>
				<li><a href="index.html">About</a></li>		
			</ul>		
		</div>	
		
		<form id="quick-search" action="index.html" method="get" >
			<p>
			<label for="qsearch">Search:</label>
			<input class="tbox" id="qsearch" type="text" name="qsearch" value="Search..." title="Start typing and hit ENTER" />
			<input class="btn" type="submit" value="Submit" />
			</p>
		</form>			
				
	<!--header ends-->					
	</div>
	
	<!-- content-wrap starts -->
	<div id="content-wrap">
				
		<div id="main">
			<?php if ($title): ?>
			<h2><?php print $title ?></h2>
			<?php endif; ?>
			
			<?php if (!empty($messages)): print $messages; endif; ?>
			<?php if (!empty($help)): print $help; endif; ?>
			<?php if (!empty($tabs)): ?><?php print $tabs; ?><?php endif; ?>
			<?php print $content ?>
			<?php print $feed_icons ?>
		<!-- main ends -->	
		</div>
		
		<!-- sidebar starts -->
		<div id="sidebar">
			<?php if ($right): ?>
			<?php print $right ?>
			<?php endif; ?>					
		<!-- sidebar ends -->		
		</div>
		
	<!-- content-wrap ends-->	
	</div>
		
	<!-- footer starts here -->	
	<div id="footer-wrap"><div id="footer-content">
	
		<div class="col float-left space-sep">
		
			<h3>Resources</h3>
			<ul class="col-list">				
				<li><a href="http://www.webdesignerwall.com/">Web Designer Wall - <span>Design Trends and Tutorials</span></a></li>
				<li><a href="http://www.cssmania.com/">CSSMania - <span>CSS Design Showcase</span></a></li>
				<li><a href="http://www.alistapart.com/">AListApart - <span>For People Who Make Websites</span></a></li>
				<li><a href="http://www.psdtuts.com/">PSDTuts.com - <span>Photoshop Tutorials And Links</span></a></li>
				<li><a href="http://www.pdphoto.org/">PDPhoto.org - <span>Public Domain Photos</span></a></li>						
				<li><a href="http://www.freephotos.se/">FreePhotos.se - <span>Free &amp; Public Domain Photos</span></a></li>	
				<li><a href="http://www.fotolia.com/partner/114283">Fotolia - <span>Free stock images or from $1</span></a></li>						
				<li><a href="http://www.4templates.com/?aff=ealigam">4templates - <span>Low Cost Hi-Quality Templates</span></a></li>	
				<li><a href="http://www.opendesigns.org/">Opendesigns - <span>Download Free Web Design Templates</span></a></li>
			</ul>		
				
		</div>
		
		<div class="col float-left">
		
			<h3>Lorem Ipsum</h3>
			
			<p>
			<strong>Lorem ipsum dolor</strong> <br />
			Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec libero. Suspendisse bibendum. 
			Cras id urna. Morbi tincidunt, orci ac convallis aliquam, lectus turpis varius lorem, eu 
			posuere nunc justo tempus leo. Donec mattis, purus nec placerat bibendum, dui pede condimentum 
			odio, ac blandit ante orci ut diam. <a href="index.html">Read more...</a>
			</p>
			
			<ul class="col-list">				
				<li><a href="index.html">consequat molestie</a></li>
				<li><a href="index.html">sem justo</a></li>
				<li><a href="index.html">semper</a></li>
				<li><a href="index.html">magna sed purus</a></li>
				<li><a href="index.html">tincidunt</a></li>						
			</ul>
				
		</div>		
	
		<div class="col2 float-right">
		
			<h3>About</h3>			
			
			<p>
			<a href="http://getfirefox.com/"><img src="images/thumb.jpg" width="40" height="40" alt="firefox" class="float-left" /></a>
			Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec libero. Suspendisse bibendum. 
			Cras id urna. Morbi tincidunt, orci ac convallis aliquam, lectus turpis varius lorem, eu 
			posuere nunc justo tempus leo. Donec mattis, purus nec placerat bibendum, dui pede condimentum 
			odio, ac blandit ante orci ut diam.</p>
			
			<p>
			Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec libero. Suspendisse bibendum. 
			Cras id urna. <a href="index.html">Learn more...</a></p>
			
			<p>
			&copy; copyright 2008 <strong>Your Company Name</strong><br /> 
			Design by: <a href="index.html">styleshout</a> &nbsp; &nbsp;
			Valid <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> | 
		   	   <a href="http://validator.w3.org/check/referer">XHTML</a>
			</p>
		
			<p>						
				<a href="index.html">Home</a> |
				<a href="index.html">Sitemap</a> |
				<a href="index.html">RSS Feed</a>								
			</p>	
			
		</div>		
			
	</div></div>
	<div class="clearer"></div>
	<!-- footer ends here -->

<!-- wrap ends here -->
</div>

</body>
</html>

