<?php
// $id: page.tpl.php, 2008/11/04 gibbo Exp $
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php print $language->language ?>" lang="<?php print $language->language ?>" dir="<?php print $language->dir ?>">

<head>
<?php print $head ?>
<title><?php print $head_title ?></title>	
<?php print $styles ?>		
<?php print $scripts ?>
</head>

<body>

<!-- wrap starts here -->
<div id="wrap">

	<!--header -->
	<div id="header">			
		
		<!-- ชื่อเว็บไซต์ -->
		<?php if ($site_name): ?>
		<h1 id="logo-text">
			<a href="<?php print check_url($front_page) ?>" title="Go To Homepage">
				<?php print $site_name ?>
			</a>
		</h1>	
		<?php endif; ?>
		
		<!-- สโลแกน -->
		<?php if ($site_slogan): ?>
		<p id="intro"><?php print $site_slogan ?>	</p>
		<?php endif; ?>
		
		<!-- ลิ้งค์หลักของเว็บ -->
		<?php if (isset($primary_links)) : ?>
		<div  id="nav">
		<?php print theme('links', $primary_links) ?>
		</div>			
		<?php endif; ?>
		
		<!-- กล่องค้นหาด้านบน -->
		<?php print $search_box ?>		
				
	<!--header ends-->					
	</div>
	
	<!-- content-wrap starts -->
	<div id="content-wrap">
			
		<!-- ส่วนเนื้อหาหลัก -->
		<div id="main">
		
			<!-- ชื่อหัวข้อหรือโพสต์ -->
			<?php if ($title): ?>
			<h2><?php print $title ?></h2>
			<?php endif; ?>
			
			<!-- แสดงข้อความแจ้งจากระบบ -->
			<?php if (!empty($messages)): print $messages; endif; ?>
			
			<!-- แสดงข้อความช่วยเหลือ -->
			<?php if (!empty($help)): print $help; endif; ?>
			
			<!-- tab จัดการเนื้อหา -->
			<?php if (!empty($tabs)): ?><?php print $tabs; ?><?php endif; ?>
			
			<!-- node อยู่ในนี้ -->
			<?php print $content ?>
			
			<!-- ไอค่อนและลิ้งค์ feed -->
			<?php print $feed_icons ?>
		<!-- main ends -->	
		</div>
		
		<!-- sidebar starts -->
		<div id="sidebar">
			<?php if ($right): ?>
			<!-- ส่วน block ด้านข้าง -->
			<?php print $right ?>
			<?php endif; ?>					
		<!-- sidebar ends -->		
		</div>
		
	<!-- content-wrap ends-->	
	</div>
		
	<!-- footer starts here -->	
	<div id="footer-wrap">
	<div id="footer-content">

		<?php if ($footer_1): ?>
		<div class="col float-left space-sep">
		<?php print $footer_1 ?>			
		</div>
		<?php endif; ?>
		
		<?php if ($footer_2): ?>
		<div class="col float-left">
		<?php print $footer_2 ?>
		</div>		
		<?php endif; ?>
		
		<?php if ($footer_3): ?>
		<div class="col2 float-right">
		<?php print $footer_3 ?>
		</div>
		<?php endif; ?>
	
		<?php if ($footer_message): ?>
		<!-- เครดิตของเว็บไซต์ -->
		<p class="clearer"><?php print $footer_message ?></p>
		<?php endif; ?>
		<p class="clearer">
		<a rel="license" href="http://creativecommons.org/licenses/by/2.5/">Some Rights Reserved.</a> <a href="http://www.styleshout.com/templates/preview/Colourise1-0/index.html">Colourise</a> Original Design from <a href="http://www.styleshout.com/">StyleShout.com</a> | Modified and Ported to Drupal by <a href="http://webzer.net/themes/colourise">Webzer.net</a>.</p>
		
	</div>
	</div>

	<div class="clearer"></div>
	<!-- footer ends here -->

<!-- wrap ends here -->
</div>
<!-- สคริปต์อื่นๆ (ถ้ามี) -->
<?php print $closure ?>
</body>
</html>
